import { createRunner, isHealth } from './runner.mjs'

const read = async key => (await chrome.storage.local.get(key))[key]
const call = async (tab, kind, command, payload = {}) => {
  let answer
  try { answer = await chrome.tabs.sendMessage(tab, { kind, command, ...payload }) }
  catch { const error = new Error('頁面已切換或連線中斷，將只嘗試讀回結果'); error.uncertain = true; throw error }
  if (!answer?.ok) throw new Error(answer?.error || '頁面連線中斷，請保持健康優選和賣貨便頁面開啟')
  return answer.data
}
const io = {
  load: () => read('job'), save: job => chrome.storage.local.set({ job }),
  hasPilot: () => read('pilotPassed'), pilotPassed: () => chrome.storage.local.set({ pilotPassed: true }),
  uuid: () => crypto.randomUUID(), now: () => new Date().toISOString(),
  source: async (job, command, data) => {
    const tab = await chrome.tabs.get(job.source_tab)
    if (!isHealth(tab.url) || new URL(tab.url).origin !== new URL(job.source_url).origin) throw new Error('健康優選頁面已關閉或已切換網址')
    return call(job.source_tab, 'health-call', command, data)
  },
  target: async (job, command, data) => {
    const tab = await chrome.tabs.get(job.target_tab)
    if (new URL(tab.url).origin !== 'https://myship.7-11.com.tw' || !new URL(tab.url).pathname.startsWith('/seller/order/')) throw new Error('請在原賣貨便分頁開啟本批的匯入結果，再讀回')
    return call(job.target_tab, 'myship-call', command, data)
  },
  findTarget: async () => {
    const tabs = await chrome.tabs.query({ url: 'https://myship.7-11.com.tw/seller/order/*' })
    const found = []
    for (const tab of tabs) {
      try { await call(tab.id, 'myship-call', 'preflight'); found.push(tab) } catch { /* Only a clean, recognized import form is eligible. */ }
    }
    if (found.length !== 1) throw new Error(found.length ? '找到多個匯入頁，請只保留本次使用的那一個' : '請在同一個比特瀏覽器環境開啟賣貨便「訂單工具 → 訂單匯入」，並保持頁面尚未選檔')
    return found[0]
  },
  waitResult: async job => {
    const deadline = Date.now() + 120000
    let reason = '賣貨便尚未顯示本批結果'
    while (Date.now() < deadline) {
      try {
        const result = await io.target(job, 'result')
        if (result.file) return result.file
        reason = result.reason || reason
        if (result.unsupported) throw new Error(reason)
      } catch (error) { if (!error.uncertain) throw error; reason = error.message }
      await new Promise(resolve => setTimeout(resolve, 2000))
    }
    throw new Error(`${reason}。批次仍保留，請在賣貨便開啟本批結果後按「讀回上一批結果」`)
  },
}
const runner = createRunner(io)
chrome.runtime.onMessage.addListener((message, sender, respond) => {
  if (sender.id !== chrome.runtime.id || sender.frameId !== 0) return
  if (message?.type === 'pulse' && sender.url?.startsWith('https://myship.7-11.com.tw/seller/order/')) { respond({ ok: true }); return }
  if (!isHealth(sender.url) || !sender.tab?.id) return
  const input = { source_tab: sender.tab.id, source_url: sender.url, order_ids: message.order_ids, marketplace_id: message.marketplace_id }
  const task = message.type === 'hello' || message.type === 'status'
    ? Promise.all([read('job'), read('pilotPassed')]).then(([job, pilot]) => ({ version: '0.2.0', job: job || null, pilot: !!pilot }))
    : message.type === 'start' ? runner.start(input)
    : message.type === 'recover' ? runner.recover(input) : null
  if (!task) return
  task.then(data => respond({ ok: true, data }), error => respond({ ok: false, error: error.message || '助手處理失敗' }))
  return true
})
