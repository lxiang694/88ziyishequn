import './compat.js'
import { createRunner, isHealth, HEALTH_ORIGINS } from './runner.mjs'

const CHANNEL = 'health-myship-assistant-v1'
const browserCall = globalThis.HealthMyshipCompat.call
const read = async key => (await browserCall(chrome.storage.local, 'get', key))[key]
const call = async (tab, kind, command, payload = {}) => {
  let answer
  try { answer = await browserCall(chrome.tabs, 'sendMessage', tab, { kind, command, ...payload }) }
  catch { const error = new Error('頁面已切換或連線中斷，將只嘗試讀回結果'); error.uncertain = true; throw error }
  if (!answer?.ok) throw new Error(answer?.error || '頁面連線中斷，請保持健康優選和賣貨便頁面開啟')
  return answer.data
}
const io = {
  load: () => read('job'), save: job => browserCall(chrome.storage.local, 'set', { job }),
  hasPilot: () => read('pilotPassed'), pilotPassed: () => browserCall(chrome.storage.local, 'set', { pilotPassed: true }),
  uuid: () => crypto.randomUUID(), now: () => new Date().toISOString(),
  source: async (job, command, data) => {
    const tab = await browserCall(chrome.tabs, 'get', job.source_tab)
    if (!isHealth(tab.url) || new URL(tab.url).origin !== new URL(job.source_url).origin) throw new Error('健康優選頁面已關閉或已切換網址')
    return call(job.source_tab, 'health-call', command, data)
  },
  target: async (job, command, data) => {
    const tab = await browserCall(chrome.tabs, 'get', job.target_tab)
    if (new URL(tab.url).origin !== 'https://myship.7-11.com.tw' || !new URL(tab.url).pathname.startsWith('/seller/order/')) throw new Error('請在原賣貨便分頁開啟本批的匯入結果，再讀回')
    return call(job.target_tab, 'myship-call', command, data)
  },
  findTarget: async () => {
    const tabs = await browserCall(chrome.tabs, 'query', { url: 'https://myship.7-11.com.tw/seller/order/*' })
    const found = []
    for (const tab of tabs) {
      try { await call(tab.id, 'myship-call', 'preflight'); found.push(tab) } catch { /* Only a clean, recognized import form is eligible. */ }
    }
    if (found.length !== 1) throw new Error(found.length ? '找到多個匯入頁，請只保留本次使用的那一個' : '請在同一個比特瀏覽器環境開啟賣貨便「訂單工具 → 訂單匯入」，並保持頁面尚未選檔')
    return found[0]
  },
  waitResult: async job => {
    const deadline = Date.now() + 120000
    let reason = '賣貨便尚未顯示本批結果'
    while (Date.now() < deadline) {
      try {
        const result = await io.target(job, 'result')
        if (result.file) return result.file
        reason = result.reason || reason
        if (result.unsupported) throw new Error(reason)
      } catch (error) { if (!error.uncertain) throw error; reason = error.message }
      await new Promise(resolve => setTimeout(resolve, 2000))
    }
    throw new Error(`${reason}。批次仍保留，請在賣貨便開啟本批結果後按「讀回上一批結果」`)
  },
}
const runner = createRunner(io)
async function handle(message, sender) {
  if (sender.frameId !== 0 || !Number.isInteger(sender.tab?.id) || sender.tab.id < 0) throw new Error('請在健康優選工作台的主分頁使用助手')
  const senderOrigin = new URL(sender.url).origin
  if (!HEALTH_ORIGINS.includes(senderOrigin) || (sender.origin && sender.origin !== senderOrigin)) throw new Error('助手僅接受健康優選工作台的連線')
  // SPA navigation can leave the message sender's original document URL unchanged.
  // Authorize the browser's current tab as well as the sender origin, never a payload URL alone.
  const tab = await browserCall(chrome.tabs, 'get', sender.tab.id)
  if (!isHealth(tab?.url) || new URL(tab.url).origin !== senderOrigin) throw new Error('請開啟健康優選「賣貨便工作台」後重新檢查連線')
  if (message.source_url && (!isHealth(message.source_url) || new URL(message.source_url).origin !== senderOrigin)) throw new Error('工作台網址已變更，請重新整理健康優選頁面')
  if (message.type === 'hello' || message.type === 'status') {
    const [job, pilot] = await Promise.all([read('job'), read('pilotPassed')])
    return { version: chrome.runtime.getManifest().version, job: job || null, pilot: !!pilot }
  }
  const input = { source_tab: sender.tab.id, source_url: tab.url, order_ids: message.order_ids, marketplace_id: message.marketplace_id }
  return message.type === 'start' ? runner.start(input) : runner.recover(input)
}
chrome.runtime.onMessage.addListener((message, sender, respond) => {
  if (sender.id !== chrome.runtime.id) return
  if (message?.type === 'pulse' && sender.frameId === 0 && sender.url?.startsWith('https://myship.7-11.com.tw/seller/order/')) { respond({ ok: true }); return }
  if (!['hello', 'status', 'start', 'recover'].includes(message?.type)) return
  // Accept the previous helper envelope until the user refreshes an existing page.
  if (message.channel && message.channel !== CHANNEL) return
  handle(message, sender).then(data => respond({ ok: true, data }), error => respond({ ok: false, error: error.message || '助手背景程式處理失敗，請重新開啟此瀏覽器環境' }))
  return true
})
